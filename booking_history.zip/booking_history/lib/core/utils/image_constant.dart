class ImageConstant {
  static String imgGroup9 = 'assets/images/img_group9.svg';

  static String imgGroup8 = 'assets/images/img_group8.svg';

  static String imgGroup11 = 'assets/images/img_group11.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
